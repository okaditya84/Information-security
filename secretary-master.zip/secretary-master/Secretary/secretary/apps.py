from django.apps import AppConfig


class SecretaryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'secretary'
